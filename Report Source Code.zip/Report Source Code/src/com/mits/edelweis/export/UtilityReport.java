package com.mits.edelweis.export;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.ClassNames;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentElement;
import com.filenet.api.core.ContentReference;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.util.Id;
import com.mits.edelweiss.VWUtils.PropertiesUtil;

public class UtilityReport 
{

	public  void commitReportToCE() {

		 Logger log=Logger.getLogger(UtilityReport.class);
			Properties props = PropertiesUtil.getInstance();

		FileNetConnection filenetConn = null;
		ObjectStore os=null;

		try {
			filenetConn = new FileNetConnection();
			os=filenetConn.getCEConnection();

			log.info("Object store name:::"+os);

			Document doc = Factory.Document.createInstance(os,props.getProperty("ReportClassName"));

			System.out.println("doc"+doc);
			
			Date DocDate= new Date();
			
			String docName=props.getProperty("DocumentName");
			String mimeType=props.getProperty("MimeType");
			String filePath=props.getProperty("filePath");;
			String folderPath=props.getProperty("folderPath");;
			doc.getProperties().putValue("DocumentTitle",docName+""+""+""+DocDate);
			doc.set_MimeType(mimeType);

			doc.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);

			File internalFile = new File(filePath);

			ContentTransfer ctObject = (ContentTransfer) Factory.ContentTransfer.createInstance();
			FileInputStream fileIS = new FileInputStream(internalFile.getAbsolutePath());
			ContentElementList contentList = Factory.ContentTransfer.createList();
			(ctObject).setCaptureSource(fileIS);
			ctObject.set_ContentType(mimeType);
			ctObject.set_RetrievalName(docName);
			// Add ContentTransfer object to list.
			contentList.add(ctObject);

			doc.set_ContentElements(contentList);
			doc.save(RefreshMode.NO_REFRESH);

			Folder folder = Factory.Folder.fetchInstance(os, folderPath, null );
			ReferentialContainmentRelationship rcr = folder.file(doc, AutoUniqueName.AUTO_UNIQUE, "DMS Report File", DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
			rcr.save(RefreshMode.NO_REFRESH);
			
			log.info("Report Generated Susscessfully");
			
		}
		catch (Exception e)
		{
			log.info("Exception occured "+e.getMessage() );
		}
		finally
		{
			filenetConn = null;
			os=null;
		}


	}
}
