package com.mits.edelweis.export;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.mits.edelweiss.VWUtils.PropertiesUtil;

public class FinalReport{
	Logger log = Logger.getLogger(FinalReport.class);


	public <report> HSSFWorkbook finalreport()
	{
	Properties props = PropertiesUtil.getInstance();
		EdelweissOperation exportdata  = new EdelweissOperation();

		EdelweissOperation eventdata  = new EdelweissOperation();
        DBdatacapreport dbreport= new DBdatacapreport();
		String pbcount=dbreport.pendingCount();

		log.info("pbcount"+pbcount+ ":"+dbreport.pendingCount());
		JSONArray finalJsonArrayReportData;
		{

			finalJsonArrayReportData = exportdata.Rosterexport();
			log.info("++++++++++++++++++++"+finalJsonArrayReportData);
			HSSFWorkbook exportdata1 = new HSSFWorkbook();
			HSSFSheet sheet = exportdata1.createSheet("Document Count Report");
			HSSFSheet sheet1 = exportdata1.createSheet("Workflow TAT");
			//HeadersDocument Count Report

			// exportdata1.set
              sheet.setDefaultColumnWidth(20);
              Font font = exportdata1.createFont();
              font.setFontName("Arial");
              CellStyle style = exportdata1.createCellStyle();

              style.setFillForegroundColor(HSSFColor.GREY_50_PERCENT.index);

              style.setFillPattern(CellStyle.SOLID_FOREGROUND);

              font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);

              font.setColor(HSSFColor.WHITE.index);

              style.setFont(font);

              style.setAlignment(style.ALIGN_CENTER);
              
              sheet1.setDefaultColumnWidth(30);
              Font font1 = exportdata1.createFont();
              font1.setFontName("Arial");
              CellStyle style1 = exportdata1.createCellStyle();

              style1.setFillForegroundColor(HSSFColor.GREY_50_PERCENT.index);

              style1.setFillPattern(CellStyle.SOLID_FOREGROUND);

              font1.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
              font1.setCharSet(11);
              font1.setColor(HSSFColor.WHITE.index);

              style1.setFont(font1);

              style1.setAlignment(style1.ALIGN_CENTER);
			HSSFRow createRow2=sheet.createRow(0);
				//createRow2.setRowStyle(style);

			log.info("Final json array object data:::::::::::::"+finalJsonArrayReportData);
			log.info("Final json array object data"+finalJsonArrayReportData);
			createRow2.createCell(2).setCellValue("Status");
			createRow2.getCell(2).setCellStyle(style);

			createRow2.createCell(3).setCellValue("Count");
			createRow2.getCell(3).setCellStyle(style);
		
		
			
			JSONArray statusList = new JSONArray();
			JSONArray finalStatusList = new JSONArray();
		
			for (int i = 0; i < finalJsonArrayReportData.size(); i++) {
				
				JSONObject object = (JSONObject) finalJsonArrayReportData.get(i);

				log.info("status of work item:::"+object.get("Status").toString());
				
				statusList.add(object.get("Status").toString());
				//uniqSBU.add(object.get("Status").toString());
			}
			JSONArray uniqSBU= new JSONArray();
			uniqSBU.add("Pending");
			uniqSBU.add("In Progress");
			uniqSBU.add("Pending for dispatch");
			uniqSBU.add("Dispatched");
			uniqSBU.add("Archived");
			
				Iterator<String> iterator = uniqSBU.iterator();
				
				int temp=1;
				while(iterator.hasNext()){
					String next = iterator.next();
					log.info("next"+next);
					int count=0;
					for(int i=0 ;i<statusList.size(); i++){
						if(next.equals(statusList.get(i))){
							count++;
						}
						
					}
					HSSFRow createRow1 = sheet.createRow(temp);
					
					log.info("pending count::"+props.getProperty("Status."+next.replace(" ","")));
					
					if("Tagging Pending".equals(props.getProperty("Status."+next.replace(" ","")))){
						createRow1.createCell(2).setCellValue(props.getProperty("Status."+next.replace(" ","")));
						
						log.info("Status of pending count:::::::::::: "+"Status."+next.trim());
						
						createRow1.createCell(3).setCellValue(pbcount);
					}
					else
					{
					createRow1.createCell(2).setCellValue(props.getProperty("Status."+next.replace(" ","")));
					
					log.info("Status of count :::::::::::::::::::::::"+"Status."+next.trim());
					
					createRow1.createCell(3).setCellValue(count);
					}
					temp++;
					
				}
			
			HSSFRow createRow = sheet1.createRow(0);
			createRow.createCell(4).setCellValue(props.getProperty("LOB"));
			createRow.getCell(4).setCellStyle(style1);
			createRow.createCell(5).setCellValue(props.getProperty("Product"));
			createRow.getCell(5).setCellStyle(style1);
			createRow.createCell(3).setCellValue(props.getProperty("SBU"));
			createRow.getCell(3).setCellStyle(style1);
			createRow.createCell(2).setCellValue(props.getProperty("Entity"));
			createRow.getCell(2).setCellStyle(style1);
			createRow.createCell(6).setCellValue(props.getProperty("RecordNames"));
			createRow.getCell(6).setCellStyle(style1);
			createRow.createCell(7).setCellValue(props.getProperty("WFCreatedates"));
			createRow.getCell(7).setCellStyle(style1);
			createRow.createCell(1).setCellValue(props.getProperty("Client"));
			createRow.getCell(1).setCellStyle(style1);
			createRow.createCell(12).setCellValue(props.getProperty("DateofArchival"));
			createRow.getCell(12).setCellStyle(style1);
			createRow.createCell(10).setCellValue(props.getProperty("DispatchDate"));
			createRow.getCell(10).setCellStyle(style1);
			createRow.createCell(8).setCellValue(props.getProperty("ScanDate"));
			createRow.getCell(8).setCellStyle(style1);
			createRow.createCell(9).setCellValue(props.getProperty("TagDate"));
			createRow.getCell(9).setCellStyle(style1);
			createRow.createCell(0).setCellValue(props.getProperty("UniqueIds"));
			createRow.getCell(0).setCellStyle(style1);
			createRow.createCell(13).setCellValue(props.getProperty("Status"));
			createRow.getCell(13).setCellStyle(style1);
			createRow.createCell(11).setCellValue(props.getProperty("ProcessCompleteDate"));
			createRow.getCell(11).setCellStyle(style1);



			for (int i = 0; i < finalJsonArrayReportData.size(); i++) {
				Row createRow1 = sheet1.createRow(i+1);
				JSONObject object = (JSONObject) finalJsonArrayReportData.get(i);
				for (int j = 0; j < object.size(); j++) {
					
					createRow1.createCell(4).setCellValue(object.get("LOB").toString());
					createRow1.createCell(5).setCellValue(object.get("Product").toString());
					createRow1.createCell(3).setCellValue(object.get("SBU").toString());
					createRow1.createCell(2).setCellValue(object.get("Entity").toString());
					createRow1.createCell(6).setCellValue(object.get("RecordName").toString());
					createRow1.createCell(7).setCellValue(object.get("WFCreatedate").toString());
					createRow1.createCell(1).setCellValue(object.get("Client").toString());
					createRow1.createCell(12).setCellValue(object.get("DateofArchival").toString());
					createRow1.createCell(10).setCellValue(object.get("DispatchDate").toString());
					createRow1.createCell(8).setCellValue(object.get("ScanDate").toString());
					createRow1.createCell(9).setCellValue(object.get("TagDate").toString());
					createRow1.createCell(0).setCellValue(object.get(props.getProperty("UniqueId")).toString());
					createRow1.createCell(13).setCellValue(object.get("Status").toString());
					createRow1.createCell(11).setCellValue(object.get("ProcessCompleteDate").toString());

				}
			}
			FileOutputStream fileOut;
			try {
				fileOut = new FileOutputStream(props.getProperty("filePath"));
			exportdata1.write(fileOut);
			fileOut.close();
			//Closing the workbook
			exportdata1 = null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			//report exportdata1 = null;
			return exportdata1;
	}
		
	}
	
	public static void main(String[] args) {
		
		FinalReport report = new FinalReport();
		
		report.finalreport();
	}
	}


