package com.mits.edelweis.export;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.mits.edelweiss.VWUtils.PropertiesUtil;

import filenet.vw.api.VWDataField;
import filenet.vw.api.VWFetchType;
import filenet.vw.api.VWLog;
import filenet.vw.api.VWLogElement;
import filenet.vw.api.VWLogQuery;
import filenet.vw.api.VWSession;

public class Eventlogreport {


	private static final Object packetID = null;

	Logger log = Logger.getLogger(Eventlogreport.class);

	Properties props = PropertiesUtil.getInstance();
	public  JSONArray Eventlogexport(){

		final String F_Subject = props.getProperty("F_Subject");
		//	private static final int F_EventType = 160;

		final String F_EventType = props.getProperty("F_EventType");
		final String archivedStatus = props.getProperty("Status.Archived");

		final String F_StartTime = props.getProperty("F_StartTime");
		int archivedcount3;

		FileNetConnection filenetConn = null;
		@SuppressWarnings("rawtypes")
		String indexName = null;

		Object[] firstValues = null;
		Object[] lastValues = null;
		String filter ="F_Subject ='"+F_Subject+"' and F_EventType='"+F_EventType+"' and Status='"+archivedStatus+"'";
		Object[] substitutionVars=null;
		int fetchType = VWFetchType.FETCH_TYPE_WORKOBJECT;

		JSONArray jsonArray = new JSONArray();
		try {
			filenetConn = new FileNetConnection();
			log.info(filenetConn);
			VWSession session = filenetConn.createPEConnection();
			log.info("createPEConnection+++++++"+session);
			log.info("this is session++++"+session.isLoggedOn());

			log.info("Before Event log filter ::"+filter);
			int queryFlags = VWLog.QUERY_NO_OPTIONS;
			VWLog eventLog = session.fetchEventLog(props.getProperty("EventLog"));

			VWLogQuery eventQuery = eventLog.startQuery(indexName, firstValues, lastValues, queryFlags, filter, null);
			int counter = 0;
			VWLogElement logElement;
			String[] fieldNames;
			int i;
			log.info("Log Element Count: "+eventQuery.fetchCount());
			while(eventQuery.hasNext()) {
				logElement = (VWLogElement) eventQuery.next();
				JSONObject jsonObject = new JSONObject();
				String Client="";
				if(null != logElement.getDataField("Client") )
				{
					log.info("Client value:::::"+logElement.getDataField("Client").toString());
					if(null != logElement.getDataField("Client").toString() && !logElement.getDataField("Client").toString().equalsIgnoreCase(""))
					{
						Client =logElement.getDataField("Client").toString();
					}
				}
				jsonObject.put("Client",Client);	

				String LOB="";
				if(null != logElement.getDataField("LOB") )
				{
					log.info("LOB value:::::"+logElement.getDataField("LOB").toString());
					if(null != logElement.getDataField("LOB").toString() && !logElement.getDataField("LOB").toString().equalsIgnoreCase(""))
					{
						LOB =logElement.getDataField("LOB").toString();
					}
				}
				jsonObject.put("LOB",LOB);

				String Entity="";
				if(null != logElement.getDataField("Entity"))
				{
					log.info("Entity value:::::"+logElement.getDataField("Entity").toString());
					if(null != logElement.getDataField("Entity").toString() && !logElement.getDataField("Entity").toString().equalsIgnoreCase(""))
					{
						Entity =logElement.getDataField("Entity").toString();
					}
				}
				jsonObject.put("Entity",Entity);

				String SBU="";
				if(null != logElement.getDataField("SBU") )
				{
					log.info("SBU value:::::"+logElement.getDataField("SBU").toString());
					if(null != logElement.getDataField("SBU").toString() && !logElement.getDataField("SBU").toString().equalsIgnoreCase(""))
					{
						SBU =logElement.getDataField("SBU").toString();
					}
				}
				jsonObject.put("SBU",SBU);

				String Product="";
				if(null != logElement.getDataField("Product") )
				{
					log.info("Product value:::::"+logElement.getDataField("Product").toString());
					if(null != logElement.getDataField("Product").toString() && !logElement.getDataField("Product").toString().equalsIgnoreCase(""))
					{
						Product =logElement.getDataField("Product").toString();
					}
				}
				jsonObject.put("Product",Product);

				String Status="";
				if(null != logElement.getDataField("Status") )
				{
					log.info("Status value:::::"+logElement.getDataField("Status").toString());
					if(null != logElement.getDataField("Status").toString() && !logElement.getDataField("Status").toString().equalsIgnoreCase(""))
					{
						Status =logElement.getDataField("Status").toString();
					}
				}
				jsonObject.put("Status",Status);

				String RecordName="";
				if(null != logElement.getDataField("RecordName") )
				{
					log.info("RecordName value:::::"+logElement.getDataField("RecordName").toString());
					if(null != logElement.getDataField("RecordName").toString() && !logElement.getDataField("RecordName").toString().equalsIgnoreCase(""))
					{
						RecordName =logElement.getDataField("RecordName").toString();
					}
				}
				jsonObject.put("RecordName",RecordName);

				String PacketID= "";
				if(null != logElement.getDataField(props.getProperty("UniqueId")))
				{
					String packetID=logElement.getDataField(props.getProperty("UniqueId")).toString();

					if(null!=packetID)
					{
						PacketID=packetID;	
					}
					else
					{
						PacketID="";	
					}
				}

				jsonObject.put(props.getProperty("UniqueId"),PacketID);

				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Date parsedDate = format.parse((logElement.getDataField(props.getProperty("WFCreatedate")).toString()));
				log.info("jsonObject::::::::::::::"+jsonObject);
				log.info("parsedDate:::::::::::"+parsedDate);
				SimpleDateFormat print = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
				String format2 = print.format(parsedDate);

				Date date=new Date(format2);
				log.info("WFCreatedate:::::::::::"+date);

				String DispatchDate="";
				if(null != logElement.getDataField("DispatchDate") )
				{
					if(null != logElement.getDataField("DispatchDate").toString() && !logElement.getDataField("DispatchDate").toString().equalsIgnoreCase(""))
					{

						SimpleDateFormat format4 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
						Date parsedDate2 = format4.parse(logElement.getDataField(("DispatchDate")).toString());

						SimpleDateFormat print2 = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
						String format5 = print2.format(parsedDate2);

						Date date2=new Date(format5);

						DispatchDate=date2.toString();
					}
				}
				log.info("DispatchDate:::::::::::"+DispatchDate);
				String ScanDate="";
				if(null != logElement.getDataField("ScanDate") )
				{
					if(null != logElement.getDataField("ScanDate").toString() && !logElement.getDataField("ScanDate").toString().equalsIgnoreCase(""))
					{
						SimpleDateFormat format6 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
						Date parsedDate3 = format6.parse(logElement.getDataField(("ScanDate")).toString());
						SimpleDateFormat print3 = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
						String format7 = print3.format(parsedDate3);

						Date date3=new Date(format7);

						ScanDate=date3.toString();
					}
				}
				log.info("ScanDate:::::::::::"+ScanDate);
				String TagDate="";
				if(null != logElement.getDataField("TagDate") )
				{
					if(null != logElement.getDataField("TagDate").toString() && !logElement.getDataField("TagDate").toString().equalsIgnoreCase(""))
					{
						SimpleDateFormat format8 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
						Date parsedDate4 = format8.parse(logElement.getDataField(("TagDate")).toString());
						SimpleDateFormat print4 = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
						String format9 = print4.format(parsedDate4);

						Date date4=new Date(format9);

						TagDate=date4.toString();
					}
				}

				log.info("TagDate:::::::::::"+TagDate);
				String processCompDate="";
				if(null != logElement.getDataField("ProcessCompleteDate"))
				{
					if(null != logElement.getDataField("ProcessCompleteDate").toString() && !logElement.getDataField("ProcessCompleteDate").toString().equalsIgnoreCase(""))
					{
						SimpleDateFormat format10 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

						Date parsedDate5 = format10.parse(logElement.getDataField(("ProcessCompleteDate")).toString());
						SimpleDateFormat print5 = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
						String format11 = print5.format(parsedDate5);

						Date date5=new Date(format11);

						processCompDate = date5.toString();

					}
				}

				log.info("processCompDate:::::::::::"+processCompDate);
				log.info("date value "+date);

				jsonObject.put("WFCreatedate",date.toString());
				String field = logElement.getDataField("Status").toString();

				log.info("field values"+field);

				String DateofArchival="";
				//Date date1 = null;
				if(null != logElement.getDataField("DateofArchival") )

					log.info("field values after if");
				{

					if(null != logElement.getDataField("DateofArchival").toString() && !logElement.getDataField("DateofArchival").toString().equalsIgnoreCase(""))
					{

						SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
						Date parsedDate1 = format1.parse(logElement.getDataField(("DateofArchival")).toString());
						SimpleDateFormat print1 = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
						String format3 = print1.format(parsedDate1);

						Date date1=new Date(format3);

						log.info("Date of Archival:::::::::::"+date1);

						DateofArchival=date1.toString();
					}

				}

				log.info(" DateofArchival "+DateofArchival);
				jsonObject.put("DateofArchival",DateofArchival);
				jsonObject.put("DispatchDate",DispatchDate);

				jsonObject.put("ProcessCompleteDate",processCompDate);
				jsonObject.put("ScanDate",ScanDate);
				jsonObject.put("TagDate",TagDate);
				log.info("date value "+date);
				jsonObject.put("WFCreatedate",date.toString());

				jsonArray.add(jsonObject);			
				if(field.equalsIgnoreCase("Archived")){
				}
				log.info("JSONarray:::::"+jsonArray+":::: event log Count::::");
			}

		}
		catch (Exception e) {

			log.error("Exception Event log"+e.getMessage());
			log.error(e.getStackTrace());
			e.printStackTrace();
		}
		return jsonArray;
	}
}
